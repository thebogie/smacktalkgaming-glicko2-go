angucomplete
============

AngularJS Autocomplete Directive
